import React from 'react';






const Cardticket = () => {
    

    const col = {
        width: '30%',
    };
    
    return (
        <>
           <div style={col}>
            <img/>
            <h3>Ha Noi</h3>
            <p>Fri 28 Nov 2021</p>
            <p>Hanoi faith and hope. We always waiting for you</p>
            </div>   
        </>
    );
};

export default Cardticket;