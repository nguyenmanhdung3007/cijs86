import React from 'react';


const Ticket_lists = {
    backgroundColor: '#FFF',
    marginTop: '15px',
    listStyle: 'none',
    fontSize: '15px',
    padding: '11px 16px',
    borderBottom: '2px solid #333'  
};

const Ticketlist = () => {
    return (
        <>
        <ul style={Ticket_lists}>
            <li>September</li>
        </ul>
        </>
    );
};

export default Ticketlist;